from menu3.menu3 import Menu
__version__ = "1.0"